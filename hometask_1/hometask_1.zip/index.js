let name = prompt('Hello, user! What is your name?');

alert(`Nice to meet you ${name}`);


